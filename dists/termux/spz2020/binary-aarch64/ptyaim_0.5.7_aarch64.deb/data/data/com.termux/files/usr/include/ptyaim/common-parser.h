/*
 * ptyaim: common-parser.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * This object facilitates in parsing input from a ptyaim_ilink structure.
 * Create a NULL-terminated array of ptyaim_parse_item structures, and you'll
 * be able to pass them to functions like ptyaim_proto_new().
 */

#ifndef __PTYAIM_COMMON_PARSER_H__
#define __PTYAIM_COMMON_PARSER_H__ 1

#include <ptyaim/common-link.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 * The callback will be casted to a different function pointer depending on
 * what event you're receiving.  For example, the "message" event handler
 * will look like this:
 *
 * 	void message_handler
 * 	(
 * 		struct ptyaim_link *,
 * 		const char *nick, const char *msg,
 * 		int emote_p
 * 	);
 *
 * And the parse_item initializer will look like this:
 *
 * 	{"message", "ssi", (ptyaim_parser_callback_t)message_hander},
 */
typedef void (*ptyaim_parser_callback_t)();

struct ptyaim_parse_item	/* Create a NULL-terminated array of these */
{
	const char *name;	/* What type of link message? */
	const char *args;	/* Args, e.g. "ssi" == string, string int */

	ptyaim_parser_callback_t callback;
};

void ptyaim_proc_link( struct ptyaim_parse_item *, struct ptyaim_ilink * );

#ifdef __cplusplus
}
#endif
#endif
