/*
 * ptyaim: proto-prompt.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * An object for protocol plugins to create "prompts."
 */

#ifndef __PTYAIM_PROTO_PROMPT_H__
#define __PTYAIM_PROTO_PROMPT_H__ 1

#include <dynbuf.h>

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_prompt
{
	struct dynbuf items;
	int n;
};

struct ptyaim_prompt *ptyaim_prompt_new();
void ptyaim_prompt_free( struct ptyaim_prompt * );

void ptyaim_prompt_reply( struct ptyaim_prompt *, int id, int yesno );

struct ptyaim_prompt_item
{
	int id;
	void *extra_bytes;

	void (*accept)( struct ptyaim_prompt_item *, void *extra_bytes );
	void (*reject)( struct ptyaim_prompt_item *, void *extra_bytes );
	void (*free)( void *extra_bytes );	/* can be NULL */
};

struct ptyaim_prompt_item *ptyaim_prompt
(
	struct ptyaim_prompt *base,
	void (*accept)( struct ptyaim_prompt_item *, void *extra_bytes ),
	void (*reject)( struct ptyaim_prompt_item *, void *extra_bytes ),
	size_t extra_bytes, void (*free)( void *extra_bytes )
);

#ifdef __cplusplus
}
#endif
#endif
