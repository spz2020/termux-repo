/*
 * ptyaim: common-link.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * This object represents the link between client and plugins, which send
 * messages through pipes.
 */

#ifndef __PTYAIM_COMMON_LINK_H__
#define __PTYAIM_COMMON_LINK_H__ 1

#include <dynbuf.h>
#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_ilink;

struct ptyaim_link
{
	int infd, outfd;
	struct dynbuf out;
	struct dynbuf in;

	void *tag;
	void (*lost_connection)( void *tag, struct ptyaim_link * );
	void (*got_input)(void*tag, struct ptyaim_link*, struct ptyaim_ilink*);
};

struct ptyaim_link *ptyaim_link_new
(
	int infd, int outfd,
	void (*lost_connection)( void *tag, struct ptyaim_link * ),
	void (*got_input)(void*tag, struct ptyaim_link*, struct ptyaim_ilink*),
	void *tag
);
void ptyaim_link_free( struct ptyaim_link *lnk );

struct ptyaim_ilink
{
	char *name;
	char *p, *e;	/* ignore these two */
	
	struct ptyaim_link *lnk;
};


/*
 * out functions
 */
void ptyaim_olink_start( struct ptyaim_link *lnk, const char *cmd );
void ptyaim_olink_string( struct ptyaim_link *lnk, const char *str );
void ptyaim_olink_int( struct ptyaim_link *lnk, int l );
void ptyaim_olink_end( struct ptyaim_link *lnk );

void ptyaim_olink_command
(
	struct ptyaim_link *lnk, const char *cmd, const char *args, ...
);
void ptyaim_olink_vcommand
(
	struct ptyaim_link *lnk, const char *cmd, const char *args, va_list ap
);

/*
 * in functions
 */
size_t ptyaim_ilink_next( struct ptyaim_link *lnk, struct ptyaim_ilink *ptr );
char *ptyaim_ilink_string( struct ptyaim_ilink *lnk );
int ptyaim_ilink_int( struct ptyaim_ilink *lnk );

#ifdef __cplusplus
}
#endif
#endif
