/*
 * ptyaim: proto-spoll.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * A pollable socket object.
 */

#ifndef __PTYAIM_PROTO_SPOLL_H__
#define __PTYAIM_PROTO_SPOLL_H__ 1

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_poll;
typedef struct _ptyaim_sock
{
	int fd;
	struct ptyaim_poll *poll;
	struct dynbuf out;

	void *tag;
	int set;
	int in_loop, please_kill;

	/*
	 * For connected sockets
	 */
	void (*lost_connection)( void *, struct _ptyaim_sock * );
	void (*got_input)( void *, struct _ptyaim_sock *, struct dynbuf *in );

	/*
	 * For listening sockets
	 */
	void (*got_socket)
	(
		void *, struct _ptyaim_sock *parent, struct _ptyaim_sock *child
	);
	void (*listen_free)( void *, struct _ptyaim_sock * );
} *ptyaim_sock_t;

ptyaim_sock_t ptyaim_socket_new
(
	struct ptyaim_poll *poll, const char *host, int port,
	void (*lost_connection)( void *, struct _ptyaim_sock * ),
	void (*got_input)( void *, struct _ptyaim_sock *, struct dynbuf *in ),
	void *tag
);

ptyaim_sock_t ptyaim_socket_listen
(
	struct ptyaim_poll *p, int af, int port, int backlog,
	void (*lost_connection)(void *, struct _ptyaim_sock *),
	void (*got_input)(void*, struct _ptyaim_sock *, struct dynbuf *in),
	void (*got_socket)(void*, struct _ptyaim_sock *, struct _ptyaim_sock *),
	void (*listen_free)( void *, struct _ptyaim_sock * ),
	void *tag
);

size_t ptyaim_socket_buffer_size( ptyaim_sock_t s );

int ptyaim_socket_try_flush( ptyaim_sock_t );

int ptyaim_socket_flush( ptyaim_sock_t );

void ptyaim_socket_write( ptyaim_sock_t, const void *, size_t );

const char *ptyaim_socket_peer( ptyaim_sock_t r );

const char *ptyaim_socket_self( ptyaim_sock_t r );

int ptyaim_socket_af( ptyaim_sock_t sock );

void ptyaim_socket_close( ptyaim_sock_t );

#ifdef __cplusplus
}
#endif
#endif
