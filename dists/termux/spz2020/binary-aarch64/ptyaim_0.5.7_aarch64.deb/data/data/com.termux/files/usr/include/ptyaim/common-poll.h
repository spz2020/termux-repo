/*
 * ptyaim: common-poll.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * A wrapper around the poll() system call.
 */

#ifndef __PTYAIM_COMMON_POLL_H__
#define __PTYAIM_COMMON_POLL_H__ 1

#include <dynbuf.h>

#ifdef _WIN32
#include <ptyaim/w32poll.h>
#else
#include <sys/poll.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_poll_item;
struct ptyaim_poll
{
	struct dynbuf pollfd;
	struct dynbuf items;
	int removed;
};

#define PTYAIM_POLL_INIT	{DYNBUF_INIT_N(512), DYNBUF_INIT_N(512),0}
#define PTYAIM_POLL_INIT_STATIC {DYNBUF_INIT_STATIC_N(512),\
				DYNBUF_INIT_STATIC_N(512),0}

void ptyaim_poll_init( struct ptyaim_poll * );
size_t ptyaim_poll_n( struct ptyaim_poll * );
void ptyaim_poll_free( struct ptyaim_poll * );

void ptyaim_poll_add
(
	struct ptyaim_poll *, int fd, short req,
	void (*poll)( void *, struct ptyaim_poll_item *, struct pollfd * ),
	void *tag
);

void ptyaim_poll_add_event( struct ptyaim_poll *, int fd, short req );

void ptyaim_poll_remove( struct ptyaim_poll *, int fd );

int ptyaim_poll( struct ptyaim_poll *, int timeout );

struct ptyaim_poll_item
{
	int fd;
	struct dynbuf in, out;
	short request;

	void (*poll)(void *tag, struct ptyaim_poll_item *, struct pollfd *);
	void *tag;
};

#ifdef __cplusplus
}
#endif
#endif
