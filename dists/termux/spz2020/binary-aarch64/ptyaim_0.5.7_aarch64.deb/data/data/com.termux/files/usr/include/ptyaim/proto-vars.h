/*
 * ptyaim: proto-vars.h			Copyright (C) 2005 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * Header for handling variables.
 */

#ifndef __PTYAIM_PROTO_VARS_H__
#define __PTYAIM_PROTO_VARS_H__ 1

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_string
{
	const char *name;
	const char *value;
	int malloced_p;
	const char *desc;
};

struct ptyaim_int
{
	const char *name;
	int value;
	const char *desc;
};

const char *ptyaim_get_string( struct ptyaim_string *p, const char *name );
void ptyaim_set_string( struct ptyaim_string *p, const char *n, const char *v );
int *ptyaim_get_int( struct ptyaim_int *p, int sizeof_p, const char *name );

#ifdef __cplusplus
}
#endif
#endif
