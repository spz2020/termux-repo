/*
 * ptyaim: proto-notify.h	Copyright (C) 2003 - 2004 Andy Sveikauskas
 * -----------------------------------------------------------------------
 * Some common proto -> client link commands.
 */

#ifndef __PTYAIM_PROTO_NOTIFY_H__
#define __PTYAIM_PROTO_NOTIFY_H__ 1

#include <stdarg.h>

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_string;
struct ptyaim_int;
struct ptyaim_parse_item;

void ptyaim_caps_notify
(
	struct ptyaim_parse_item *items,
	struct ptyaim_string *svars,
	struct ptyaim_int *ivars,
	unsigned int nints
);

void ptyaim_whoami( const char *yournick );
void ptyaim_chnick_notify( const char *old, const char *new );

void ptyaim_message_notify( const char *user, const char *msg, int self );
void ptyaim_chat_notify( const char *chan, const char *user, const char *msg );
void ptyaim_status_notify( const char *user, int flags, int on_or_off );
void ptyaim_info_notify( const char *user, const char *profile );

struct ptyaim_prompt_item;

void ptyaim_prompt_notify
(
	struct ptyaim_prompt_item *,
	const char *caption,	/* think of this like a window title bar */
	const char *body	/* "would you like to... ?" */
);

void ptyaim_puts( const char *s );
void ptyaim_printf( const char *fmt, ... );
void ptyaim_vprintf( const char *fmt, va_list ap );

void ptyaim_notify( const char *name, const char *args, ... );
void ptyaim_vnotify( const char *name, const char *args, va_list ap );

#ifdef __cplusplus
}
#endif
#endif
