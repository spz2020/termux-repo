/*
 * ptyaim: proto.h			Copyright (C) 2005 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * Header for protocol plugins.
 */

#include <ptyaim/common.h>
#include <ptyaim/proto-spoll.h>
#include <ptyaim/proto-notify.h>
#include <ptyaim/proto-prompt.h>
#include <ptyaim/proto-new.h>
#include <ptyaim/proto-vars.h>
