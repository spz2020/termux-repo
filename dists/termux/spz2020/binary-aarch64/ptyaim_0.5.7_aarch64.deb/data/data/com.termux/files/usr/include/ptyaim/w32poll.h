/*
 * ptyaim: w32poll.h			Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * A Win32 implementation of the poll() system call.
 */

#ifndef __PTYAIM_W32POLL_H__
#define __PTYAIM_w32POLL_H__ 1

#ifdef __cplusplus
extern "C" {
#endif

struct pollfd
{
	int fd;
	short events, revents;
	/*
	 * The Win32 HANDLE to wait on instead of the fd.
	 * This can be NULL, in which case we use the fd.
	 */
	void *ev;
};

int poll( struct pollfd *fds, unsigned int n, int timeout );

#define POLLIN		1
#define POLLOUT		2

#ifdef __cplusplus
}
#endif
#endif
