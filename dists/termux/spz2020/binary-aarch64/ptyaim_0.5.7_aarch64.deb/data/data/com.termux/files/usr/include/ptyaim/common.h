/*
 * ptyaim: common.h			Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * This header is included by both client.h and proto.h.
 */

#ifndef __PTYAIM_COMMON_H__
#define __PTYAIM_COMMON_H__ 1

#include <ptyaim/common-link.h>
#include <ptyaim/common-poll.h>
#include <ptyaim/common-plink.h>
#include <ptyaim/common-parser.h>
#include <ptyaim/common-int.h>

#ifdef _WIN32
#define PATH_SEP	"\\"
#else
#define PATH_SEP	"/"
#endif

#ifdef __cplusplus
extern "C" {
#endif

const char *ptyaim_os_name();
const char *ptyaim_home();
const char *ptyaim_user_name();
const char *ptyaim_real_name();
const char *ptyaim_host_name();

int ptyaim_strcmp( const char *a, const char *b );

enum ptyaim_status
{
	STATUS_ONLINE	= 1,
	STATUS_IDLE	= (1<<2),
	STATUS_AWAY	= (1<<3),
	STATUS_OP	= (1<<4),
	STATUS_VOICE	= (1<<5),
	STATUS_NEWMSG	= (1<<6),
	STATUS_VISIBLE	= (1<<7),
	STATUS_ALIASED	= (1<<8),
	STATUS_OFFLINE	= 0
};

#ifdef __cplusplus
#endif
#endif
