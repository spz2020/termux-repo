/*
 * ptyaim: client.h			Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * Users of libptyaim which wish to implement a client should include this
 * header.
 */

#include <ptyaim/common.h>
#include <ptyaim/client-new.h>
#include <ptyaim/client-calls.h>
