/*
 * <dynbuf.h>		Copyright (C) 2001-2004 Andy Sveikauskas 
 *--------------------------------------------------------------
 *
 * This code allows for relatively easy buffering that will
 * automatically realloc() what you need and more.  It also
 * tries to reduce the number of realloc()s, among other
 * fabulous, wonderful things.
 *
 * This code is licensed under the terms of the GNU General Public
 * License, version 2 or later.  You are free to redistribute it
 * under the terms of this license, which can be obtained from the
 * Free Software Foundation, or its website at http://www.fsf.org.
 *
 * This software is provided without warranty of any kind.
 */

#ifndef __DYNBUF_H__
#define __DYNBUF_H__ 1

#include <stddef.h>
#include <stdlib.h>
#include <stdarg.h>

#ifdef USE_PUBLIB
#include <publib.h>
#else
#ifdef __cplusplus
extern "C" {
#endif
void *xmalloc( size_t );
void *xrealloc( void *, size_t );
#define xfree free
char *xstrdup( const char * );
#ifdef __cplusplus
}
#endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

struct dynbuf {
	void *buf;
	size_t bs, len, alloc;
	int static_fl;
};

#ifndef DYNBUF_SIZE
#define DYNBUF_SIZE		64	/* default block size */
#endif

#define DYNBUF_INIT_N(bs)	{NULL,bs,0,0,	0}
#define DYNBUF_INIT		DYNBUF_INIT_N(0)

#define DYNBUF_INIT_N_STATIC(bs){NULL,bs,0,0,	1}
#define DYNBUF_INIT_STATIC	DYNBUF_INIT_N_STATIC(0)

#define DYNBUF_INIT_STATIC_N	DYNBUF_INIT_N_STATIC

void dynbuf_init( struct dynbuf *d, size_t block_size );
void dynbuf_free( struct dynbuf * );

void dynbuf_static( struct dynbuf * );

void *dynbuf_alloc( struct dynbuf *d, size_t size );
void *dynbuf_insert( struct dynbuf *d, size_t offset, size_t len );
void dynbuf_remove( struct dynbuf *d, size_t offset, size_t len );

void *dynbuf_copy( struct dynbuf *d, const void *p, size_t len );
void *dynbuf_cat( struct dynbuf *obj, const struct dynbuf *obj2 );
void *dynbuf_dup
(
	struct dynbuf *unitialized_object,
	const struct dynbuf *object_to_be_copied
);
char *dynbuf_strcat( struct dynbuf *d, const char *p );
char *dynbuf_strdup( struct dynbuf *d, const char *p );

char *dynbuf_vprintf( struct dynbuf *b, const char *fmt, va_list ap );
char *dynbuf_printf( struct dynbuf *d, const char *fmt, ... );

char *dynbuf_zstrcat( struct dynbuf *d, const char *p );
char *dynbuf_zstrdup( struct dynbuf *d, const char *p );
char *dynbuf_zvprintf( struct dynbuf *b, const char *fmt, va_list ap );
char *dynbuf_zprintf( struct dynbuf *d, const char *fmt, ... );

#define DYNBUF(x)	((struct dynbuf *)(x))

#define dynbuf_p(db,tp)		((tp*)(DYNBUF(db)->buf))
#define dynbuf_alloc_p(db,tp,n)	((tp*)(dynbuf_alloc(DYNBUF(db),sizeof(tp)*(n))))
#define dynbuf_l(db)		(DYNBUF(db)->len)
#define dynbuf_len		dynbuf_l
#define dynbuf_n(db,tp)		(dynbuf_l(db)/sizeof(tp))
#define dynbuf_bs(db)		(DYNBUF(db)->bs)
#define dynbuf_block_size	dynbuf_bs

#define dynbuf_clear(db)	(dynbuf_l(db) = 0)

#define dynbuf_insert_p(db,tp,i,n) \
	(tp*)(dynbuf_insert(DYNBUF(db), (i)*sizeof(tp), (n)*sizeof(tp))) 

#define dynbuf_insert_pp(db,p,n) \
	dynbuf_insert(DYNBUF(db),p-DYNBUF(db)->buf,(n)*sizeof((*p)))

#define dynbuf_remove_n(db,n,nmemb,type) \
	dynbuf_remove(DYNBUF(db),(n)*sizeof(type),(nmemb)*sizeof(type))
#define dynbuf_remove_p(db,p,n) \
	dynbuf_remove(DYNBUF(db),((char*)(p))-dynbuf_p(db,char),(n)*sizeof(*(p)))

#define dynbuf_copy_p(db, p, nmemb) \
	dynbuf_copy(DYNBUF(db), p, (nmemb)*sizeof(*(p)))

#define dynbuf_zero_terminate(db) \
	(*dynbuf_alloc_p(DYNBUF(db),char,1) = 0)
#define dynbuf_zerot	dynbuf_zero_terminate

#ifdef __cplusplus
}
#endif

#endif
