/*
 * ptyaim: common-plink.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * This code aids using ptyaim_poll with ptyaim_link.
 */

#ifndef __COMMON_PLINK_H__
#define __COMMON_PLINK_H__ 1

#include <ptyaim/common-link.h>
#include <ptyaim/common-poll.h>

#ifdef __cplusplus
extern "C" {
#endif

void ptyaim_poll_add_link
(
	struct ptyaim_poll *p, struct ptyaim_link *lnk
);

void ptyaim_poll_remove_link
(
	struct ptyaim_poll *p, struct ptyaim_link *lnk
);

#ifdef __cplusplus
}
#endif
#endif
