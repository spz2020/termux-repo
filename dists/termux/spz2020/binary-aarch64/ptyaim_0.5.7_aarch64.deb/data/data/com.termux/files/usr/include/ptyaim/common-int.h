/*
 * ptyaim: common-int.h			Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * Wraps uint16_t, uint32_t, htons(), htonl(), etc. so that libptyaim users
 * do not have to detect them for portability reasons.
 */

#ifndef __PTYAIM_COMMON_INT_H__
#define __PTYAIM_COMMON_INT_H__ 1

#ifdef __cplusplus
extern "C" {
#endif

void ptyaim_int16_set( void *set, int i );
int ptyaim_int16_get( const void *get );

void ptyaim_int32_set( void *set, int i );
int ptyaim_int32_get( const void *get );

#ifdef __cplusplus
}
#endif
#endif
