/*
 * ptyaim: proto-new.h			Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * The "protocol plugin" side of the client -> proto link.
 */

#ifndef __PTYAIM_PROTO_NEW_H__
#define __PTYAIM_PROTO_NEW_H__ 1

#ifdef __cplusplus
extern "C" {
#endif
	
struct ptyaim_link;
struct ptyaim_parse_item;

struct ptyaim_link *ptyaim_proto_new( struct ptyaim_parse_item *responses );

#ifdef __cplusplus
}
#endif
#endif
