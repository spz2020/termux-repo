/*
 * ptyaim: client-new.h			Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * Creates the "client" end of the client -> proto link.
 */

#ifndef __PTYAIM_CLIENT_NEW_H__
#define __PTYAIM_CLIENT_NEW_H__ 1

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_link;
struct ptyaim_ilink;

struct ptyaim_link *ptyaim_client_new
(
 	char **argv,	/* command line for protocol plugin */
	void (*lost_connection)( void *tag, struct ptyaim_link * ),
	void (*got_input)(void*, struct ptyaim_link*, struct ptyaim_ilink*),
	void *tag
);

#ifdef __cplusplus
}
#endif
#endif
