/*
 * ptyaim: client-calls.h		Copyright (C) 2004 Andy Sveikauskas
 * ------------------------------------------------------------------------
 * Some common client -> proto link commands.
 */

#ifndef __PTYAIM_CLIENT_CALLS_H__
#define __PTYAIM_CLIENT_CALLS_H__ 1

#ifdef __cplusplus
extern "C" {
#endif

struct ptyaim_link;

void ptyaim_config_string
(
	struct ptyaim_link *lnk, const char *setting, const char *
);
void ptyaim_config_int
(
	struct ptyaim_link *lnk, const char *setting, int
);

void ptyaim_login
(
	struct ptyaim_link * lnk, const char *login, const char *passwd
);
void ptyaim_close( struct ptyaim_link * lnk );
void ptyaim_close_window( struct ptyaim_link *, const char *user );
void ptyaim_away( struct ptyaim_link * lnk, const char *s );
void ptyaim_set_info( struct ptyaim_link * lnk, const char *s );
void ptyaim_set_nick( struct ptyaim_link * lnk, const char *nick );
void ptyaim_idle( struct ptyaim_link * lnk, int minutes );
void ptyaim_message
(
	struct ptyaim_link * lnk, const char *nick, const char *msg, int emote
);
void ptyaim_get_info( struct ptyaim_link * lnk, const char *nick );
void ptyaim_add_buddy( struct ptyaim_link * lnk, const char *nick );
void ptyaim_remove_buddy( struct ptyaim_link * lnk, const char *nick );
void ptyaim_join( struct ptyaim_link * lnk, const char *chan );
void ptyaim_part( struct ptyaim_link * lnk, const char *chan );
void ptyaim_kick
(
	struct ptyaim_link * lnk, const char *chan, const char *user,
	const char *reason
);
void ptyaim_mode
(
	struct ptyaim_link * lnk, const char *chan, const char *mode
);
void ptyaim_topic
(
	struct ptyaim_link * lnk, const char *chan, const char *topic
);
void ptyaim_ctcp
(
	struct ptyaim_link * lnk, int is_reply, const char *u, const char *c
);
void ptyaim_chat( struct ptyaim_link *lnk, const char *user );
void ptyaim_send( struct ptyaim_link *lnk, const char *u, const char *file );
void ptyaim_prompt_send_reply( struct ptyaim_link *lnk, int id, int yesno );
void ptyaim_ping( struct ptyaim_link * lnk, const char *usr );
void ptyaim_quit( struct ptyaim_link * lnk, const char *msg );

#ifdef __cplusplus
}
#endif
#endif
